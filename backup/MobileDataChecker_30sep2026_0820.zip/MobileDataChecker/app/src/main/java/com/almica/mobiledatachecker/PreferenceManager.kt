package com.almica.mobiledatachecker

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import java.util.UUID
import androidx.core.content.edit

class PreferenceManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(
        Constants.PREFS_NAME,
        Context.MODE_PRIVATE
    )

    fun getPhoneNumber(): String {
        return prefs.getString(Constants.KEY_PHONE_NUMBER, "+4915776049418") ?: "+4915776049418"
    }

    fun setPhoneNumber(number: String) {
        prefs.edit { putString(Constants.KEY_PHONE_NUMBER, number) }
    }

    fun getIntervalMinutes(): Long {
        return prefs.getLong(Constants.KEY_INTERVAL_MINS, 15L)
    }

    fun setIntervalMinutes(minutes: Long) {
        prefs.edit { putLong(Constants.KEY_INTERVAL_MINS, minutes) }
    }

    fun getOrCreateInstallationId(): String {
        var id = prefs.getString(Constants.KEY_INSTALLATION_ID, null)
        if (id.isNullOrEmpty()) {
            id = UUID.randomUUID().toString()
            prefs.edit { putString(Constants.KEY_INSTALLATION_ID, id) }
        }
        return id
    }
}

fun getDeviceName(): String {
    val manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
    val model = Build.MODEL

    val name = if (model.startsWith(manufacturer, ignoreCase = true)) {
        model
    } else {
        "$manufacturer $model"
    }
    return name
}
