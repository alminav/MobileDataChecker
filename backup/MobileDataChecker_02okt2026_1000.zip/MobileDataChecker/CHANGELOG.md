# Changelog

All notable changes to the MobileDataChecker project will be documented in this file.

## [Unreleased] - 2025-02-16

### Added
- **Notification Preference Support**:
  - Added `KEY_NOTIFICATIONS_ENABLED` to `Constants`.
  - Added `getNotificationsEnabled()` and `setNotificationsEnabled()` methods to `PreferenceManager`.
  - Exposed `notificationsEnabled` StateFlow and `setNotificationsEnabled()` action in `MainViewModel`.
  - Added UI switch toggle in `MainActivity` to enable/disable notifications.
  - Added `enable_notifications_label` string resources in English and German (`strings.xml` and `values-de/strings.xml`).
- **Worker Notification Check**:
  - Updated `MobileDataCheckWorker` to respect the notification preference (`isNotificationEnabled`) when mobile data is active.

### Fixed
- Fixed compilation error: `Unresolved reference 'notificationsEnabled'` in `MainActivity.kt`.
