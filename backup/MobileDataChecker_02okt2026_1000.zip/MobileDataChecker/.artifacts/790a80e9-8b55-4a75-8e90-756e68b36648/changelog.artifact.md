# Changelog - UI Improvements & Architecture Refactoring

## [0.1.0] - 2026-10-01

### Architectural Improvements
- **ViewModel Encapsulation**: Moved `PreferenceManager` initialization and `resetSendLocationCount()` logic from `MainActivity` directly into `MainViewModel#startWorker()`.
- **UI Decoupling**: Simplified `onStartWorker` lambda in [MainActivity.kt](file:///C:/Users/altmi/AndroidStudioProjects/MobileDataChecker/app/src/main/java/com/almica/mobiledatachecker/MainActivity.kt) to delegate worker startup entirely to [MainViewModel](class://com.almica.mobiledatachecker.MainViewModel), removing unnecessary context handling and storage logic from the Composable UI layer.

### Build & Verification
- Successfully verified build integrity (`app:assembleDebug`) after refactoring.
