package com.almica.mobiledatachecker

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import java.text.SimpleDateFormat
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.autofill.ContentDataType.Companion.Date
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.intl.Locale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.coroutineScope
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.android.gms.location.LocationServices
import id.zelory.compressor.Compressor
import id.zelory.compressor.constraint.destination
import id.zelory.compressor.constraint.format
import id.zelory.compressor.constraint.size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Date

@Composable
fun GeoCameraScreen(
    onDismiss: (msg: Pair<String, String>?, link: String?) -> Unit,
    viewModel: MainViewModel = viewModel()
) {
    val context = LocalContext.current
    var activeImageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    val fusedLocationClient = remember { LocationServices.getFusedLocationProviderClient(context) }
    val scope = rememberCoroutineScope()
    val lifeCycle = LocalLifecycleOwner.current.lifecycle
    BackHandler {
        onDismiss(null, null)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // 1. Live-Kamera im Hintergrund anzeigen
        CameraPreview(
            onReady = { captureObject ->
                activeImageCapture = captureObject
            }
        )

        // Close Button
        IconButton(
            onClick = { onDismiss(null, null) },
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(16.dp),
            colors = IconButtonDefaults.iconButtonColors(
                containerColor = Color.Black.copy(alpha = 0.5f),
                contentColor = Color.White
            )
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Schließen"
            )
        }

        // 2. Button zum Auslösen über dem Live-Bild platzieren
        Button(
            onClick = {
                val imageCapture = activeImageCapture
                if (imageCapture != null) {
                    val photoFile = File(context.cacheDir, "compose_geo_${getReadableDate(System.currentTimeMillis())}.jpg")
                    val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

                    imageCapture.takePicture(
                        outputOptions,
                        ContextCompat.getMainExecutor(context),
                        object : ImageCapture.OnImageSavedCallback {
                            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                // Lokales Foto existiert -> GPS holen und hochladen
                                // Aufruf innerhalb eines Coroutine-Scopes (z.B. lifecycleScope oder viewModelScope)
                                lifeCycle.coroutineScope.launch {
                                    val compressedFile =
                                        compressImageWithLibrary(context, photoFile, photoFile)
                                    Timber.i("Compressed file size: ${compressedFile.length()}")
                                    fetchLocationAndSubmit(
                                        file = compressedFile, //photoFile,
                                        fusedLocationClient = fusedLocationClient,
                                        viewModel = viewModel,
                                        onSuccess = { msg, link ->
                                            onDismiss(Pair(photoFile.name, msg), link)
                                        }
                                    )
                                }
                            }

                            override fun onError(exception: ImageCaptureException) {
                                Toast.makeText(context, "Fehler: ${exception.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                } else {
                    Toast.makeText(context, "Kamera wird noch geladen...", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 48.dp)
        ) {
            Text("Moment aufnehmen & hochladen")
        }
    }
}

/**
 * Komprimiert ein File-Objekt mit der Compressor-Library auf unter 500 KB.
 */
suspend fun compressImageWithLibrary(context: Context, inputFile: File, outputFile: File): File {
    return Compressor.compress(context, inputFile) {
        // Zielort für die komprimierte Datei festlegen
        destination(outputFile)
        // Maximal 500 KB erzwingen (512.000 Bytes)
        size(512_000)
        // Ausgabeformat als JPEG deklarieren
        format(Bitmap.CompressFormat.JPEG)
    }
}
@SuppressLint("MissingPermission")
private fun fetchLocationAndSubmit(
    file: File,
    fusedLocationClient: com.google.android.gms.location.FusedLocationProviderClient,
    viewModel: MainViewModel,
    onSuccess: (msg: String, link: String?) -> Unit
) {
    fusedLocationClient.lastLocation.addOnSuccessListener { location ->
        if (location != null) {
            val titleText = "Compose Photo (${location.latitude}, ${location.longitude})"
            //viewModel.uploadFileToBplaced(file, titleText, location) { response ->
            viewModel.uploadImageToBplaced(file) { response ->
                if (response.isSuccessful && response.body() != null) {
                    val msg = response.body()!!.message
                    val link = response.body()!!.url
                    onSuccess(msg, link)
                } else {
                    val msg = "Fehler beim Upload: ${response.code()}"
                    onSuccess(msg, null)
                }
            }
        } else {
            val msg = "Standort konnte nicht ermittelt werden."
            onSuccess(msg, null)
            if (file.exists()) file.delete()
        }
    }.addOnFailureListener {
        val msg = "Standort konnte nicht ermittelt werden."
        onSuccess(msg, null)
        if (file.exists()) file.delete()
    }
}

/**
 * Komprimiert eine Bitmap im JPEG-Format auf unter 500 KB.
 * Führen Sie diese Funktion aus einem Coroutine-Scope heraus aus.
 */
suspend fun compressBitmapToTargetSize(originalBitmap: Bitmap): ByteArray = withContext(Dispatchers.IO) {
    val targetSizeByte = 500 * 1024 // 500 KB in Bytes
    var quality = 95
    var byteArray: ByteArray

    val outputStream = ByteArrayOutputStream()

    do {
        outputStream.reset() // Stream für den nächsten Versuch leeren
        originalBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        byteArray = outputStream.toByteArray()

        // Qualität schrittweise verringern
        quality -= 5
    } while (byteArray.size > targetSizeByte && quality > 5)

    outputStream.close()
    return@withContext byteArray
}

@Composable
fun CameraPreview(
    modifier: Modifier = Modifier,
    onReady: (ImageCapture) -> Unit // Gibt das fertige ImageCapture-Objekt an den Screen zurück
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val previewView = remember { PreviewView(context) }
    val imageCapture = remember { ImageCapture.Builder().build() }

    AndroidView(
        factory = { previewView },
        modifier = modifier.fillMaxSize(),
        update = { _ ->
            val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
            cameraProviderFuture.addListener({
                val cameraProvider = cameraProviderFuture.get()

                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

                try {
                    cameraProvider.unbindAll()
                    // Wichtig: Sowohl preview ALS AUCH imageCapture an den Lifecycle binden
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        CameraSelector.DEFAULT_BACK_CAMERA,
                        preview,
                        imageCapture
                    )
                    // Signalisiert dem Screen, dass bereit zum Fotografieren ist
                    onReady(imageCapture)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }, ContextCompat.getMainExecutor(context))
        }
    )
}
fun getReadableDate(millis: Long): String {
    // 1. Das gewünschte Datumsformat definieren (Locale.GERMANY für deutsche Monatsnamen/Formate)
    val timeFormatter =  SimpleDateFormat("dd_MM_yyyy_HH_mm_ss", java.util.Locale.getDefault())

    // 2. Aus den Millisekunden ein Date-Objekt erstellen
    val netDate = Date(millis)

    // 3. Formatieren
    return timeFormatter.format(netDate)
}