// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.android.library) apply false
    alias(libs.plugins.compose.compiler) apply false
    alias(libs.plugins.kotlin.serialization) apply false
    alias(libs.plugins.kotlin.parcelize) apply false
    alias(libs.plugins.ksp) apply false
    id("idea")
}

configure<org.gradle.plugins.ide.idea.model.IdeaModel> {
    module {
        excludeDirs.add(file("backups"))
        excludeDirs.add(file("pictures"))
        excludeDirs.add(file("app/src/main/res/mipmap-hdpi"))
        excludeDirs.add(file("app/src/main/assets"))
        excludeDirs.add(file("graphhopper/src/main/assets"))
    }
}
